from django.apps import AppConfig


class WebMisperrisConfig(AppConfig):
    name = 'web_misperris'
